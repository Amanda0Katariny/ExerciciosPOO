#include<iostream>
#include<locale.h>
using namespace std;

//Classe pai
class Veiculo{
	public:
		int nr, rt;
		char ol;
	public:
		int Rodas()
		{
			cout << "Qntidade de rodas a serem consertadas: ";
			cin >> nr;
			return(nr);
		}
		int Retrovisor()
		{
			cout << "Qntidade de retrovisores a serem consertados: ";
			cin >> rt;
			return(rt);
		}
		char Oleo()
		{
			cout << ("Deseja trocar o �leo? ");
			fflush(stdin);
			ol=getchar();
			return(ol);
		}
};

//Classe filho de Ve�culo
class Moto: public Veiculo{
	public:
		char d;
	
	public:
		char Direcao()
		{
			cout << "Deseja consertar a dire��o? ";
			fflush(stdin);
			d=getchar();
			return(d);
		}
		
		void Print(int, int, char, char)
		{
			cout << "\nRodas: " << nr;
			cout <<"\nRetrovisores: " << rt;
			cout <<"\nConserto da dire��o? " << d;
			cout <<"\nTroca de �leo? " << ol;
		}
		void Inicio()
		{
			cout <<"\nManuten��o da Moto \n";
		}
};

//Classe filho de Ve�culo
class Carro: public Veiculo{
	public:
		int pt;
		
	public:
		//Uso do virtual por ser um m�todo virtualizado do m�todo da classe Moto
		virtual void Inicio()
		{
			cout << "\nManuten��o do Carro \n";
		}
		int Portas()
		{
			cout << "Qntidade de portas a serem consertadas: ";
			cin >> pt;
			return (pt);
		}
		//Uso do virtual por ser um m�todo virtualizado do m�todo da classe Moto
		virtual void Print(int, int, int, char)
		{
			cout << "\nRodas: " << nr;
			cout <<"\nRetrovisores: " << rt;
			cout <<"\nPortas: " << pt;
			cout <<"\nTroca de �leo? " << ol;
		}
};

main()
{
	setlocale(LC_ALL,"Portuguese");
	char escolha;
	Carro c1;
	Moto moto1;
	cout <<"Carro ou Moto? (c) ou (m) ";
	fflush(stdin);
	escolha=getchar();
	switch(escolha)
	{
		case 'c':

			c1.Rodas();
			c1.Retrovisor();
			c1.Portas();
			c1.Oleo();
			c1.Inicio();
			c1.Print(c1.nr,c1.rt,c1.pt,c1.ol);
 		break;
		case'm':
			moto1.Rodas();
			moto1.Retrovisor();
			moto1.Direcao();
			moto1.Oleo();
			moto1.Inicio();
			moto1.Print(moto1.nr,moto1.rt,moto1.d,moto1.ol);
	}
}
