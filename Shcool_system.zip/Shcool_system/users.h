#include<iostream>
using namespace std;

//Classe pai
class Veuiculo{
	public:
		int nr, rt;
		char ol;
	public:
		int Rodas()
		{
			cout << "Qntidade de rodas a serem consertadas: ";
			cin >> nr;
			return(nr);
		}
		int Retrovisor()
		{
			cout << "Qntidade de retrovisores a serem consertados: ";
			cin >> rt;
			return(rt);
		}
		char Oleo()
		{
			cout << ("Deseja trocar o �leo? ");
			fflush(stdin);
			ol=getchar();
			return(ol);
		}
};
