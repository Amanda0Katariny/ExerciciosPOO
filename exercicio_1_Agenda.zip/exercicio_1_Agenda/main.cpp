#include <iostream>
#include <stdlib.h>
#include <stdio.h>

class Lembrete {
public:
    char detalhes_compromisso[20];

public:
    int Alerta() {
        cout << "Descreva seu Compromisso: ";
        cin >> detalhes_compromisso;
        return(detalhes_compromisso);
    }
};

class Compromisso {
public:
    int dia_compromisso;
    int mes_compromisso;
    int ano_compromisso;
    char tipo_compromisso;
public:
    int Dia() {
        cout << "Insira o Dia do Compromisso: ";
        cin >> dia_compromisso;
        return(dia_compromisso);
    }
    int Mes() {
        cout << "Insira o Mes do Compromisso: ";
        cin >> mes_compromisso;
        return(mes_compromisso);
    }
    int Ano() {
        cout << "Insira o Ano do Compromisso: ";
        cin >> ano_compromisso;
        return(ano_compromisso);
    }
    int Tipo() {
        cout <<"Qual Tipo do Seu compromisso? Prova(P) ou Trabalho(T) ";
        cin >> tipo_compromisso;
        return(tipo_compromisso);
    }

};

class Turma {
public:
    char professor[15];
    char disciplina[15];

};

using namespace std;

int main() {
    cout << "Hello world!" << endl;
    return 0;
}
